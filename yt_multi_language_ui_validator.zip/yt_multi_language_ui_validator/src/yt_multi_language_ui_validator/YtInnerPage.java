package yt_multi_language_ui_validator;

import org.openqa.selenium.By;

public class YtInnerPage {

	By youtuberMainInfoInnerPage=By.xpath("//div[@id='above-the-fold']//div[@id='top-row']");
	
	By settingButtonUnderVideoPlayerInnerPage=By.xpath("//button[@class='ytp-button ytp-settings-button']");
	
}
